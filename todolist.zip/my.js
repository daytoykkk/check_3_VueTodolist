const { log } = console;


const app = new Vue({
    el: "#hhh",
    data: {
        todoText: '',
        todo: [
            { content: "喝奶茶", done: true, isRead:true, index:0},
            { content: "吃烧烤", done: false, isRead:true, index:1},
        ],
        activeClass:-1,
        oldTask:'',
    },
    methods: {
        addToClick: function () {
            if (this.todoText === "") {
               alert("不能为空哦！");
                return
            }
            if(this.todoText.length>15) {
                alert("不能超过15个字！");
                this.todoText="";
                return 
            }
            this.todo.push({
                content: this.todoText.trim(),
                done: false,
                isRead:true,
                isDone:"undo",
                index:this.todo.length,
            });
            this.todoText = "";

            localStorage.setItem('todo',JSON.stringify(this.todo))
         
        },
        deleteClick: function (index) {
            log(index);
            this.todo.splice(index, 1);
            localStorage.setItem('todo',JSON.stringify(this.todo))
        },
        edit: function (item) {
              oldTask=item.content;
              item.isRead = false;
              this.activeClass = item.index;
        },
        edEnd: function(item) {
            
            if(item.content.length>15) {
                 alert("不能超过15个字！");
                 item.content = oldTask;
            }
            item.isRead = true;
            this.activeClass = -1;
            localStorage.setItem('todo',JSON.stringify(this.todo))
        },
        save: function() {
            localStorage.setItem('todo',JSON.stringify(this.todo))
        }
    },
    computed:{
        doneCount(){
            return this.todo.filter(item=>{
                return item.done
            }).length
        },
        undoCount(){
            return this.todo.filter(item=>{
                return !item.done
            }).length
        },
    },
    mounted: function(){
        let list = JSON.parse(localStorage.getItem('todo'))
        if(list){
            this.todo = list;
        }
        log("mounted:"+list)
    },
})
